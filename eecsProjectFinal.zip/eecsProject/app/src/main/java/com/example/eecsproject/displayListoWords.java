package com.example.eecsproject;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class displayListoWords extends AppCompatActivity {


    ArrayAdapter<String> arrayAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_listo_words);

        ListView listView = findViewById(R.id.listview);
        SearchView searchView = findViewById(R.id.search_bar);

        List<String> words = new ArrayList<>();
        words.add("Eye");
        words.add("Nose");
        words.add("Cell");
        words.add("Brain");
        words.add("Heart");
        words.add("Nerve cells");
        words.add("Arteries");
        words.add("Veins");
        words.add("Digestive System");
        words.add("Respiratory System");

        arrayAdapter = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_list_item_1, words);
        listView.setAdapter(arrayAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                if (i == 0){
                    Intent intent = new Intent(displayListoWords.this, Eye.class);
                    startActivity(intent);
                } else if (i == 1){
                    Intent intent = new Intent(displayListoWords.this, Nose.class);
                    startActivity(intent);
                } else if (i == 2){
                    Intent intent = new Intent(displayListoWords.this, Cell.class);
                    startActivity(intent);
                } else if (i == 3){
                    Intent intent = new Intent(displayListoWords.this, Brain.class);
                    startActivity(intent);
                } else if (i == 4){
                    Intent intent = new Intent(displayListoWords.this, Heart.class);
                    startActivity(intent);
                } else if (i == 5){
                    Intent intent = new Intent(displayListoWords.this, Nerve_cells.class);
                    startActivity(intent);
                } else if (i == 6){
                    Intent intent = new Intent(displayListoWords.this, Arteries.class);
                    startActivity(intent);
                } else if (i == 7){
                    Intent intent = new Intent(displayListoWords.this, Veins.class);
                    startActivity(intent);
                } else if (i == 8){
                    Intent intent = new Intent(displayListoWords.this, Digestive_system.class);
                    startActivity(intent);
                } else if (i == 9){
                    Intent intent = new Intent(displayListoWords.this, Respiratory_system.class);
                    startActivity(intent);
                }
            }
        });

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                displayListoWords.this.arrayAdapter.getFilter().filter(query);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                displayListoWords.this.arrayAdapter.getFilter().filter(newText);
                return false;
            }
        });




    }

    public void alphabetical(View view){
        ListView listView = findViewById(R.id.listview);
        SearchView searchView = findViewById(R.id.search_bar);

        List<String> words = new ArrayList<>();
        words.add("Arteries");
        words.add("Brain");
        words.add("Cell");
        words.add("Digestive System");
        words.add("Eye");
        words.add("Heart");
        words.add("Nerve cells");
        words.add("Nose");
        words.add("Respiratory System");
        words.add("Veins");

        arrayAdapter = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_list_item_1, words);
        listView.setAdapter(arrayAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                if (i == 0){
                    Intent intent = new Intent(displayListoWords.this, Arteries.class);
                    startActivity(intent);
                } else if (i == 1){
                    Intent intent = new Intent(displayListoWords.this, Brain.class);
                    startActivity(intent);
                } else if (i == 2){
                    Intent intent = new Intent(displayListoWords.this, Cell.class);
                    startActivity(intent);
                } else if (i == 3){
                    Intent intent = new Intent(displayListoWords.this, Digestive_system.class);
                    startActivity(intent);
                } else if (i == 4){
                    Intent intent = new Intent(displayListoWords.this, Eye.class);
                    startActivity(intent);
                } else if (i == 5){
                    Intent intent = new Intent(displayListoWords.this, Heart.class);
                    startActivity(intent);
                } else if (i == 6){
                    Intent intent = new Intent(displayListoWords.this, Nerve_cells.class);
                    startActivity(intent);
                } else if (i == 7){
                    Intent intent = new Intent(displayListoWords.this, Nose.class);
                    startActivity(intent);
                } else if (i == 8){
                    Intent intent = new Intent(displayListoWords.this, Respiratory_system.class);
                    startActivity(intent);
                } else if (i == 9){
                    Intent intent = new Intent(displayListoWords.this, Veins.class);
                    startActivity(intent);
                }
            }
        });

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                displayListoWords.this.arrayAdapter.getFilter().filter(query);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                displayListoWords.this.arrayAdapter.getFilter().filter(newText);
                return false;
            }
        });
    }


    public void longest(View view){
            ListView listView = findViewById(R.id.listview);
            SearchView searchView = findViewById(R.id.search_bar);

            List<String> words = new ArrayList<>();
            words.add("Respiratory System");
            words.add("Digestive System");
            words.add("Nerve cells");
            words.add("Arteries");
            words.add("Brain");
            words.add("Heart");
            words.add("Veins");
            words.add("Nose");
            words.add("Cell");
            words.add("Eye");

            arrayAdapter = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_list_item_1, words);
            listView.setAdapter(arrayAdapter);

            listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                    if (i == 0){
                        Intent intent = new Intent(displayListoWords.this, Respiratory_system.class);
                        startActivity(intent);
                    } else if (i == 1){
                        Intent intent = new Intent(displayListoWords.this, Digestive_system.class);
                        startActivity(intent);
                    } else if (i == 2){
                        Intent intent = new Intent(displayListoWords.this, Nerve_cells.class);
                        startActivity(intent);
                    } else if (i == 3){
                        Intent intent = new Intent(displayListoWords.this, Arteries.class);
                        startActivity(intent);
                    } else if (i == 4){
                        Intent intent = new Intent(displayListoWords.this, Brain.class);
                        startActivity(intent);
                    } else if (i == 5){
                        Intent intent = new Intent(displayListoWords.this, Heart.class);
                        startActivity(intent);
                    } else if (i == 6){
                        Intent intent = new Intent(displayListoWords.this, Veins.class);
                        startActivity(intent);
                    } else if (i == 7){
                        Intent intent = new Intent(displayListoWords.this, Nose.class);
                        startActivity(intent);
                    } else if (i == 8){
                        Intent intent = new Intent(displayListoWords.this, Cell.class);
                        startActivity(intent);
                    } else if (i == 9){
                        Intent intent = new Intent(displayListoWords.this, Eye.class);
                        startActivity(intent);
                    }
                }
            });

            searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
                @Override
                public boolean onQueryTextSubmit(String query) {
                    displayListoWords.this.arrayAdapter.getFilter().filter(query);
                    return false;
                }

                @Override
                public boolean onQueryTextChange(String newText) {
                    displayListoWords.this.arrayAdapter.getFilter().filter(newText);
                    return false;
                }
            });
    }


    public void shortest(View view){
        ListView listView = findViewById(R.id.listview);
        SearchView searchView = findViewById(R.id.search_bar);

        List<String> words = new ArrayList<>();
        words.add("Eye");
        words.add("Cell");
        words.add("Nose");
        words.add("Veins");
        words.add("Heart");
        words.add("Brain");
        words.add("Arteries");
        words.add("Nerve cells");
        words.add("Digestive System");
        words.add("Respiratory System");


        arrayAdapter = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_list_item_1, words);
        listView.setAdapter(arrayAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                if (i == 0){
                    Intent intent = new Intent(displayListoWords.this, Eye.class);
                    startActivity(intent);
                } else if (i == 1){
                    Intent intent = new Intent(displayListoWords.this, Cell.class);
                    startActivity(intent);
                } else if (i == 2){
                    Intent intent = new Intent(displayListoWords.this, Nose.class);
                    startActivity(intent);
                } else if (i == 3){
                    Intent intent = new Intent(displayListoWords.this, Veins.class);
                    startActivity(intent);
                } else if (i == 4){
                    Intent intent = new Intent(displayListoWords.this, Heart.class);
                    startActivity(intent);
                } else if (i == 5){
                    Intent intent = new Intent(displayListoWords.this, Brain.class);
                    startActivity(intent);
                } else if (i == 6){
                    Intent intent = new Intent(displayListoWords.this, Arteries.class);
                    startActivity(intent);
                } else if (i == 7){
                    Intent intent = new Intent(displayListoWords.this, Nerve_cells.class);
                    startActivity(intent);
                } else if (i == 8){
                    Intent intent = new Intent(displayListoWords.this, Digestive_system.class);
                    startActivity(intent);
                } else if (i == 9){
                    Intent intent = new Intent(displayListoWords.this, Respiratory_system.class);
                    startActivity(intent);
                }
            }
        });

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                displayListoWords.this.arrayAdapter.getFilter().filter(query);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                displayListoWords.this.arrayAdapter.getFilter().filter(newText);
                return false;
            }
        });
    }
}