package com.example.eecsproject;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class displayListoWords_2 extends AppCompatActivity {


    ArrayAdapter<String> arrayAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_listo_words2);


        ListView listView = findViewById(R.id.listview);
        SearchView searchView = findViewById(R.id.search_bar);

        List<String> words = new ArrayList<>();

        words.add("Atoms");
        words.add("Compounds");
        words.add("Electrons");
        words.add("Protons");
        words.add("Solution");
        words.add("Solvent");
        words.add("Solute");
        words.add("Base");
        words.add("Acid");
        words.add("Cations");
        words.add("Anions");

        arrayAdapter = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_list_item_1, words);
        listView.setAdapter(arrayAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                if (i == 0){
                    Intent intent = new Intent(displayListoWords_2.this, Atoms.class);
                    startActivity(intent);
                } else if (i == 1){
                    Intent intent = new Intent(displayListoWords_2.this, Compounds.class);
                    startActivity(intent);
                } else if (i == 2){
                    Intent intent = new Intent(displayListoWords_2.this, Electrons.class);
                    startActivity(intent);
                } else if (i == 3){
                    Intent intent = new Intent(displayListoWords_2.this, Protons.class);
                    startActivity(intent);
                } else if (i == 4){
                    Intent intent = new Intent(displayListoWords_2.this, Solution.class);
                    startActivity(intent);
                } else if (i == 5){
                    Intent intent = new Intent(displayListoWords_2.this, Solvent.class);
                    startActivity(intent);
                } else if (i == 6){
                    Intent intent = new Intent(displayListoWords_2.this, Solute.class);
                    startActivity(intent);
                } else if (i == 7){
                    Intent intent = new Intent(displayListoWords_2.this, Base.class);
                    startActivity(intent);
                } else if (i == 8){
                    Intent intent = new Intent(displayListoWords_2.this, Acid.class);
                    startActivity(intent);
                } else if (i == 9){
                    Intent intent = new Intent(displayListoWords_2.this, Cations.class);
                    startActivity(intent);
                } else if (i == 10){
                    Intent intent = new Intent(displayListoWords_2.this, Anions.class);
                    startActivity(intent);
                }
            }
        });

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                displayListoWords_2.this.arrayAdapter.getFilter().filter(query);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                displayListoWords_2.this.arrayAdapter.getFilter().filter(newText);
                return false;
            }
        });
    }

    public void alphabetical(View view){
        ListView listView = findViewById(R.id.listview);
        SearchView searchView = findViewById(R.id.search_bar);

        List<String> words = new ArrayList<>();
        words.add("Acid");
        words.add("Anions");
        words.add("Atoms");
        words.add("Base");
        words.add("Cations");
        words.add("Compounds");
        words.add("Electrons");
        words.add("Protons");
        words.add("Solute");
        words.add("Solution");
        words.add("Solvent");

        arrayAdapter = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_list_item_1, words);
        listView.setAdapter(arrayAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                if (i == 0){
                    Intent intent = new Intent(displayListoWords_2.this, Acid.class);
                    startActivity(intent);
                } else if (i == 1){
                    Intent intent = new Intent(displayListoWords_2.this, Anions.class);
                    startActivity(intent);
                } else if (i == 2){
                    Intent intent = new Intent(displayListoWords_2.this, Atoms.class);
                    startActivity(intent);
                } else if (i == 3){
                    Intent intent = new Intent(displayListoWords_2.this, Base.class);
                    startActivity(intent);
                } else if (i == 4){
                    Intent intent = new Intent(displayListoWords_2.this, Cations.class);
                    startActivity(intent);
                } else if (i == 5){
                    Intent intent = new Intent(displayListoWords_2.this, Compounds.class);
                    startActivity(intent);
                } else if (i == 6){
                    Intent intent = new Intent(displayListoWords_2.this, Electrons.class);
                    startActivity(intent);
                } else if (i == 7){
                    Intent intent = new Intent(displayListoWords_2.this, Protons.class);
                    startActivity(intent);
                } else if (i == 8){
                    Intent intent = new Intent(displayListoWords_2.this, Solute.class);
                    startActivity(intent);
                } else if (i == 9){
                    Intent intent = new Intent(displayListoWords_2.this, Solution.class);
                    startActivity(intent);
                } else if (i == 10){
                    Intent intent = new Intent(displayListoWords_2.this, Solvent.class);
                    startActivity(intent);
                }
            }
        });

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                displayListoWords_2.this.arrayAdapter.getFilter().filter(query);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                displayListoWords_2.this.arrayAdapter.getFilter().filter(newText);
                return false;
            }
        });
    }


    public void longest(View view){
        ListView listView = findViewById(R.id.listview);
        SearchView searchView = findViewById(R.id.search_bar);

        List<String> words = new ArrayList<>();
        words.add("Acid");//4
        words.add("Base");//4
        words.add("Atoms");//5
        words.add("Anions");//6
        words.add("Solute");//6
        words.add("Protons");//7
        words.add("Cations");//7
        words.add("Solvent");//7
        words.add("Solution");//8
        words.add("Compounds");//9
        words.add("Electrons");//9


        arrayAdapter = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_list_item_1, words);
        listView.setAdapter(arrayAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                if (i == 0){
                    Intent intent = new Intent(displayListoWords_2.this, Acid.class);
                    startActivity(intent);
                } else if (i == 1){
                    Intent intent = new Intent(displayListoWords_2.this, Base.class);
                    startActivity(intent);
                } else if (i == 2){
                    Intent intent = new Intent(displayListoWords_2.this, Atoms.class);
                    startActivity(intent);
                } else if (i == 3){
                    Intent intent = new Intent(displayListoWords_2.this, Anions.class);
                    startActivity(intent);
                } else if (i == 4){
                    Intent intent = new Intent(displayListoWords_2.this, Solute.class);
                    startActivity(intent);
                } else if (i == 5){
                    Intent intent = new Intent(displayListoWords_2.this, Protons.class);
                    startActivity(intent);
                } else if (i == 6){
                    Intent intent = new Intent(displayListoWords_2.this, Cations.class);
                    startActivity(intent);
                } else if (i == 7){
                    Intent intent = new Intent(displayListoWords_2.this, Solvent.class);
                    startActivity(intent);
                } else if (i == 8){
                    Intent intent = new Intent(displayListoWords_2.this, Solution.class);
                    startActivity(intent);
                } else if (i == 9){
                    Intent intent = new Intent(displayListoWords_2.this, Compounds.class);
                    startActivity(intent);
                } else if (i == 10){
                    Intent intent = new Intent(displayListoWords_2.this, Electrons.class);
                    startActivity(intent);
                }
            }
        });

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                displayListoWords_2.this.arrayAdapter.getFilter().filter(query);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                displayListoWords_2.this.arrayAdapter.getFilter().filter(newText);
                return false;
            }
        });
    }


    public void shortest(View view){
        ListView listView = findViewById(R.id.listview);
        SearchView searchView = findViewById(R.id.search_bar);

        List<String> words = new ArrayList<>();

        words.add("Electrons");//9
        words.add("Compounds");//9
        words.add("Solution");//8
        words.add("Solvent");//7
        words.add("Cations");//7
        words.add("Protons");//7
        words.add("Solute");//6
        words.add("Anions");//6
        words.add("Atoms");//
        words.add("Base");//4
        words.add("Acid");//4



        arrayAdapter = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_list_item_1, words);
        listView.setAdapter(arrayAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                if (i == 0){
                    Intent intent = new Intent(displayListoWords_2.this, Electrons.class);
                    startActivity(intent);
                } else if (i == 1){
                    Intent intent = new Intent(displayListoWords_2.this, Compounds.class);
                    startActivity(intent);
                } else if (i == 2){
                    Intent intent = new Intent(displayListoWords_2.this, Solution.class);
                    startActivity(intent);
                } else if (i == 3){
                    Intent intent = new Intent(displayListoWords_2.this, Solvent.class);
                    startActivity(intent);
                } else if (i == 4){
                    Intent intent = new Intent(displayListoWords_2.this, Cations.class);
                    startActivity(intent);
                } else if (i == 5){
                    Intent intent = new Intent(displayListoWords_2.this, Protons.class);
                    startActivity(intent);
                } else if (i == 6){
                    Intent intent = new Intent(displayListoWords_2.this, Solute.class);
                    startActivity(intent);
                } else if (i == 7){
                    Intent intent = new Intent(displayListoWords_2.this, Anions.class);
                    startActivity(intent);
                } else if (i == 8){
                    Intent intent = new Intent(displayListoWords_2.this, Atoms.class);
                    startActivity(intent);
                } else if (i == 9){
                    Intent intent = new Intent(displayListoWords_2.this, Base.class);
                    startActivity(intent);
                } else if (i == 10){
                    Intent intent = new Intent(displayListoWords_2.this, Acid.class);
                    startActivity(intent);
                }
            }
        });

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                displayListoWords_2.this.arrayAdapter.getFilter().filter(query);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                displayListoWords_2.this.arrayAdapter.getFilter().filter(newText);
                return false;
            }
        });
    }
}