package com.example.eecsproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;

public class HumanVerification extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_human_verification);
    }


    public void verfiy(View view) {
        View v1 = findViewById(R.id.Descrip);
        EditText user = (EditText) v1;
        String username = user.getText().toString();
        CheckBox test = findViewById(R.id.checkBox);

        if (!username.equals("Hand") && !username.equals("hand") && !username.equals("HAND")) {
            TextView output = (TextView) findViewById(R.id.outputText);
            output.setText("Please correctly enter what is described above in the text box");
        } else if (!test.isChecked()){
            TextView output = (TextView) findViewById(R.id.outputText);
            output.setText("Please check the verify box");
        } else {
            Intent intent = new Intent(HumanVerification.this, account.class);
            startActivity(intent);
        }
    }
}