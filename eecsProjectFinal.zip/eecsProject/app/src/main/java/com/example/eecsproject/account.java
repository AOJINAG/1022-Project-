package com.example.eecsproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class account extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account);
        details.add("omar");
        details.add("ok");
        details.add("mariia");
        details.add("okok");
        details.add("ao");
        details.add("okokok");
        details.add("shunyao");
        details.add("okokokok");
    }

    List<String> details = new ArrayList<String>();

    // The List places all usernames at odd positions and their corresponding password in the
    // index following that username's position



    public void signIn(View view){

        View v1 = findViewById(R.id.username_log);
        EditText user = (EditText) v1;
        String username = user.getText().toString();

        View v2 = findViewById(R.id.password_log);
        EditText pass = (EditText) v2;
        String password = pass.getText().toString();

        if (details.contains(username)){
            if (details.get(details.indexOf(username) + 1).equals(password)){
                Intent intent = new Intent(account.this, themeSelection.class);
                startActivity(intent);
            } else {
                TextView output = (TextView) findViewById(R.id.TVmessage);
                output.setText("Password is incorrect");
            }
        } else {
            TextView output = (TextView) findViewById(R.id.TVmessage);
            output.setText("Invalid username");
        }
    }

    public void createAcc(View view){

        View v1 = findViewById(R.id.username_reg);
        EditText user = (EditText) v1;
        String username = user.getText().toString();

        View v2 = findViewById(R.id.password_reg_1);
        EditText password_one = (EditText) v2;
        String password1 = password_one.getText().toString();

        View v3 = findViewById(R.id.password_reg_2);
        EditText password_two = (EditText) v3;
        String password2 = password_two.getText().toString();

        if (!username.contains("#") || !username.contains("@") || username.contains("!") || !username.contains("*") || !username.contains("%") || !username.contains("$") || !username.contains("&")){
            if (username.length() >= 6 && username.length() <= 30){
                if (password1.equals(password2)){
                    details.add(username);
                    details.add(password1);
                    Intent intent = new Intent(account.this, themeSelection.class);
                    startActivity(intent);
                } else {
                    TextView output = (TextView) findViewById(R.id.TVmessage_2);
                    output.setText("Passwords don't match");
                }
            } else {
                TextView output = (TextView) findViewById(R.id.TVmessage_2);
                output.setText("Username must be between 6 and 30 characters");
            }
        } else {
            TextView output = (TextView) findViewById(R.id.TVmessage_2);
            output.setText("Username must not contain !@#$%&*");
        }
    }
}