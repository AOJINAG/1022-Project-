package com.example.eecsproject;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Orbit extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_orbit);
    }
}