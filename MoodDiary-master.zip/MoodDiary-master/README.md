MoodDiary
=======
project for CMPUT 301
1. When disconnect from the Internet, the local change will be lost
2. Do not using UI testing for guide page, map, photo, night mood and logout features. Use manually testing for those features
3. If there is only one marker in map, the map will zoom in really large
4. For tutorial coach mark page, We user the library written by huburt-Hu https://github.com/huburt-Hu/NewbieGuide
5. All emotion/system icons are from https://www.easyicon.net/
6. The diary image and friends image are created by the following these artists. 

   * https://dribbble.com/shots/6092978-My-Notebook?utm_source=Clipboard_Shot&utm_campaign=LaisyWang0912&utm_content=My%20Notebook&utm_medium=Social_Share
   
   * https://dribbble.com/shots/7780031-Friends?utm_source=Clipboard_Shot&utm_campaign=Marina_Petrovskaya&utm_content=Friends&utm_medium=Social_Share
   
   * https://dribbble.com/shots/6651176-Vlog-Era?utm_source=Clipboard_Shot&utm_campaign=LaisyWang0912&utm_content=Vlog%20Era&utm_medium=Social_Share
