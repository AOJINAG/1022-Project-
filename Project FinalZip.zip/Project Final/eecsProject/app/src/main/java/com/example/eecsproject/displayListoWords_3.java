package com.example.eecsproject;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class displayListoWords_3 extends AppCompatActivity {

    ArrayAdapter<String> arrayAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_listo_words3);


        ListView listView = findViewById(R.id.listview);
        SearchView searchView = findViewById(R.id.search_bar);


        List<String> words = new ArrayList<>();
        words.add("Corner Kick");
        words.add("Free Kick");
        words.add("Penalty Kick");
        words.add("Goalkeeper");
        words.add("Defender");
        words.add("Midfielder");
        words.add("Offside");
        words.add("Cross");
        words.add("Yellow Card");
        words.add("Red Card");

        arrayAdapter = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_list_item_1, words);
        listView.setAdapter(arrayAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                if (i == 0){
                    Intent intent = new Intent(displayListoWords_3.this, cornerKick.class);
                    startActivity(intent);
                } else if (i == 1){
                    Intent intent = new Intent(displayListoWords_3.this, freeKick.class);
                    startActivity(intent);
                } else if (i == 2){
                    Intent intent = new Intent(displayListoWords_3.this, penaltyKick.class);
                    startActivity(intent);
                } else if (i == 3){
                    Intent intent = new Intent(displayListoWords_3.this, Goalkeeper.class);
                    startActivity(intent);
                } else if (i == 4){
                    Intent intent = new Intent(displayListoWords_3.this, Defender.class);
                    startActivity(intent);
                } else if (i == 5){
                    Intent intent = new Intent(displayListoWords_3.this, Midfielder.class);
                    startActivity(intent);
                } else if (i == 6){
                    Intent intent = new Intent(displayListoWords_3.this, Offside.class);
                    startActivity(intent);
                } else if (i == 7){
                    Intent intent = new Intent(displayListoWords_3.this, Cross.class);
                    startActivity(intent);
                } else if (i == 8){
                    Intent intent = new Intent(displayListoWords_3.this, yellowCard.class);
                    startActivity(intent);
                } else if (i == 9){
                    Intent intent = new Intent(displayListoWords_3.this, redCard.class);
                    startActivity(intent);
                }
            }
        });

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                displayListoWords_3.this.arrayAdapter.getFilter().filter(query);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                displayListoWords_3.this.arrayAdapter.getFilter().filter(newText);
                return false;
            }
        });
    }

    public void alphabetical(View view){
        ListView listView = findViewById(R.id.listview);
        SearchView searchView = findViewById(R.id.search_bar);

        List<String> words = new ArrayList<>();
        words.add("Corner Kick");
        words.add("Cross");
        words.add("Defender");
        words.add("Free Kick");
        words.add("Goalkeeper");
        words.add("Midfielder");
        words.add("Offside");
        words.add("Penalty Kick");
        words.add("Red Card");
        words.add("Yellow Card");

        arrayAdapter = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_list_item_1, words);
        listView.setAdapter(arrayAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                if (i == 0){
                    Intent intent = new Intent(displayListoWords_3.this, cornerKick.class);
                    startActivity(intent);
                } else if (i == 1){
                    Intent intent = new Intent(displayListoWords_3.this, Cross.class);
                    startActivity(intent);
                } else if (i == 2){
                    Intent intent = new Intent(displayListoWords_3.this, Defender.class);
                    startActivity(intent);
                } else if (i == 3){
                    Intent intent = new Intent(displayListoWords_3.this, freeKick.class);
                    startActivity(intent);
                } else if (i == 4){
                    Intent intent = new Intent(displayListoWords_3.this, Goalkeeper.class);
                    startActivity(intent);
                } else if (i == 5){
                    Intent intent = new Intent(displayListoWords_3.this, Midfielder.class);
                    startActivity(intent);
                } else if (i == 6){
                    Intent intent = new Intent(displayListoWords_3.this, Offside.class);
                    startActivity(intent);
                } else if (i == 7){
                    Intent intent = new Intent(displayListoWords_3.this, penaltyKick.class);
                    startActivity(intent);
                } else if (i == 8){
                    Intent intent = new Intent(displayListoWords_3.this, redCard.class);
                    startActivity(intent);
                } else if (i == 9){
                    Intent intent = new Intent(displayListoWords_3.this, yellowCard.class);
                    startActivity(intent);
                }
            }
        });

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                displayListoWords_3.this.arrayAdapter.getFilter().filter(query);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                displayListoWords_3.this.arrayAdapter.getFilter().filter(newText);
                return false;
            }
        });
    }


    public void longest(View view){
        ListView listView = findViewById(R.id.listview);
        SearchView searchView = findViewById(R.id.search_bar);

        List<String> words = new ArrayList<>();
        words.add("Penalty Kick");//11
        words.add("Yellow Card");//10
        words.add("Corner Kick");//10
        words.add("Midfielder");//10
        words.add("Goalkeeper");//10
        words.add("Free Kick");//8
        words.add("Defender");//8
        words.add("Red Card");//7
        words.add("Offside");//7
        words.add("Cross");//5


        arrayAdapter = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_list_item_1, words);
        listView.setAdapter(arrayAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                if (i == 0){
                    Intent intent = new Intent(displayListoWords_3.this, penaltyKick.class);
                    startActivity(intent);
                } else if (i == 1){
                    Intent intent = new Intent(displayListoWords_3.this, yellowCard.class);
                    startActivity(intent);
                } else if (i == 2){
                    Intent intent = new Intent(displayListoWords_3.this, cornerKick.class);
                    startActivity(intent);
                } else if (i == 3){
                    Intent intent = new Intent(displayListoWords_3.this, Midfielder.class);
                    startActivity(intent);
                } else if (i == 4){
                    Intent intent = new Intent(displayListoWords_3.this, Goalkeeper.class);
                    startActivity(intent);
                } else if (i == 5){
                    Intent intent = new Intent(displayListoWords_3.this, freeKick.class);
                    startActivity(intent);
                } else if (i == 6){
                    Intent intent = new Intent(displayListoWords_3.this, Defender.class);
                    startActivity(intent);
                } else if (i == 7){
                    Intent intent = new Intent(displayListoWords_3.this, redCard.class);
                    startActivity(intent);
                } else if (i == 8){
                    Intent intent = new Intent(displayListoWords_3.this, Offside.class);
                    startActivity(intent);
                } else if (i == 9){
                    Intent intent = new Intent(displayListoWords_3.this, Cross.class);
                    startActivity(intent);
                }
            }
        });

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                displayListoWords_3.this.arrayAdapter.getFilter().filter(query);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                displayListoWords_3.this.arrayAdapter.getFilter().filter(newText);
                return false;
            }
        });
    }


    public void shortest(View view){
        ListView listView = findViewById(R.id.listview);
        SearchView searchView = findViewById(R.id.search_bar);

        List<String> words = new ArrayList<>();
        words.add("Cross");//5
        words.add("Offside");//7
        words.add("Red Card");//7
        words.add("Defender");//8
        words.add("Free Kick");//8
        words.add("Goalkeeper");//10
        words.add("Midfielder");//10
        words.add("Corner Kick");//10
        words.add("Yellow Card");//10
        words.add("Penalty Kick");//11


        arrayAdapter = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_list_item_1, words);
        listView.setAdapter(arrayAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                if (i == 0){
                    Intent intent = new Intent(displayListoWords_3.this, Cross.class);
                    startActivity(intent);
                } else if (i == 1){
                    Intent intent = new Intent(displayListoWords_3.this, Offside.class);
                    startActivity(intent);
                } else if (i == 2){
                    Intent intent = new Intent(displayListoWords_3.this, redCard.class);
                    startActivity(intent);
                } else if (i == 3){
                    Intent intent = new Intent(displayListoWords_3.this, Defender.class);
                    startActivity(intent);
                } else if (i == 4){
                    Intent intent = new Intent(displayListoWords_3.this, freeKick.class);
                    startActivity(intent);
                } else if (i == 5){
                    Intent intent = new Intent(displayListoWords_3.this, Goalkeeper.class);
                    startActivity(intent);
                } else if (i == 6){
                    Intent intent = new Intent(displayListoWords_3.this, Midfielder.class);
                    startActivity(intent);
                } else if (i == 7){
                    Intent intent = new Intent(displayListoWords_3.this, cornerKick.class);
                    startActivity(intent);
                } else if (i == 8){
                    Intent intent = new Intent(displayListoWords_3.this, yellowCard.class);
                    startActivity(intent);
                } else if (i == 9){
                    Intent intent = new Intent(displayListoWords_3.this, penaltyKick.class);
                    startActivity(intent);
                }
            }
        });

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                displayListoWords_3.this.arrayAdapter.getFilter().filter(query);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                displayListoWords_3.this.arrayAdapter.getFilter().filter(newText);
                return false;
            }
        });
    }
}