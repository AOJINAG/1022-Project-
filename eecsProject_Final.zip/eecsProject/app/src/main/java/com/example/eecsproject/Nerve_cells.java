package com.example.eecsproject;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Nerve_cells extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nerve_cells);
    }
}