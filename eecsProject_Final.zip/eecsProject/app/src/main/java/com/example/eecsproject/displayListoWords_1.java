package com.example.eecsproject;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class displayListoWords_1 extends AppCompatActivity {



    ArrayAdapter<String> arrayAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_listo_words1);

        ListView listView = findViewById(R.id.listview);
        SearchView searchView = findViewById(R.id.search_bar);

        List<String> words = new ArrayList<>();
        words.add("Continents");
        words.add("Earthquakes");
        words.add("Tsunamis");
        words.add("Canyon");
        words.add("Valley");
        words.add("Glaciers");
        words.add("Island");
        words.add("Peninsula");
        words.add("Desert");
        words.add("Volcanoes");

        arrayAdapter = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_list_item_1, words);
        listView.setAdapter(arrayAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                if (i == 0){
                    Intent intent = new Intent(displayListoWords_1.this, Continents.class);
                    startActivity(intent);
                } else if (i == 1){
                    Intent intent = new Intent(displayListoWords_1.this, Earthquake.class);
                    startActivity(intent);
                } else if (i == 2){
                    Intent intent = new Intent(displayListoWords_1.this, Tsunami.class);
                    startActivity(intent);
                } else if (i == 3){
                    Intent intent = new Intent(displayListoWords_1.this, Canyon.class);
                    startActivity(intent);
                } else if (i == 4){
                    Intent intent = new Intent(displayListoWords_1.this, Valley.class);
                    startActivity(intent);
                } else if (i == 5){
                    Intent intent = new Intent(displayListoWords_1.this, Glaciers.class);
                    startActivity(intent);
                } else if (i == 6){
                    Intent intent = new Intent(displayListoWords_1.this, Island.class);
                    startActivity(intent);
                } else if (i == 7){
                    Intent intent = new Intent(displayListoWords_1.this, Peninsula.class);
                    startActivity(intent);
                } else if (i == 8){
                    Intent intent = new Intent(displayListoWords_1.this, Desert.class);
                    startActivity(intent);
                } else if (i == 9){
                    Intent intent = new Intent(displayListoWords_1.this, Volcano.class);
                    startActivity(intent);
                }
            }
        });

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                displayListoWords_1.this.arrayAdapter.getFilter().filter(query);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                displayListoWords_1.this.arrayAdapter.getFilter().filter(newText);
                return false;
            }
        });
    }

    public void alphabetical(View view){
        ListView listView = findViewById(R.id.listview);
        SearchView searchView = findViewById(R.id.search_bar);

        List<String> words = new ArrayList<>();
        words.add("Canyon");
        words.add("Continents");
        words.add("Desert");
        words.add("Earthquakes");
        words.add("Glaciers");
        words.add("Island");
        words.add("Peninsula");
        words.add("Tsunamis");
        words.add("Valley");
        words.add("Volcanoes");

        arrayAdapter = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_list_item_1, words);
        listView.setAdapter(arrayAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                if (i == 0){
                    Intent intent = new Intent(displayListoWords_1.this, Canyon.class);
                    startActivity(intent);
                } else if (i == 1){
                    Intent intent = new Intent(displayListoWords_1.this, Continents.class);
                    startActivity(intent);
                } else if (i == 2){
                    Intent intent = new Intent(displayListoWords_1.this, Desert.class);
                    startActivity(intent);
                } else if (i == 3){
                    Intent intent = new Intent(displayListoWords_1.this, Earthquake.class);
                    startActivity(intent);
                } else if (i == 4){
                    Intent intent = new Intent(displayListoWords_1.this, Glaciers.class);
                    startActivity(intent);
                } else if (i == 5){
                    Intent intent = new Intent(displayListoWords_1.this, Island.class);
                    startActivity(intent);
                } else if (i == 6){
                    Intent intent = new Intent(displayListoWords_1.this, Peninsula.class);
                    startActivity(intent);
                } else if (i == 7){
                    Intent intent = new Intent(displayListoWords_1.this, Tsunami.class);
                    startActivity(intent);
                } else if (i == 8){
                    Intent intent = new Intent(displayListoWords_1.this, Valley.class);
                    startActivity(intent);
                } else if (i == 9){
                    Intent intent = new Intent(displayListoWords_1.this, Volcano.class);
                    startActivity(intent);
                }
            }
        });

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                displayListoWords_1.this.arrayAdapter.getFilter().filter(query);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                displayListoWords_1.this.arrayAdapter.getFilter().filter(newText);
                return false;
            }
        });
    }


    public void longest(View view){
        ListView listView = findViewById(R.id.listview);
        SearchView searchView = findViewById(R.id.search_bar);

        List<String> words = new ArrayList<>();
        words.add("Earthquakes"); //11
        words.add("Continents"); //10
        words.add("Volcanoes");//10
        words.add("Peninsula"); //9
        words.add("Glaciers"); //8
        words.add("Tsunamis"); //7
        words.add("Canyon"); //6
        words.add("Valley"); //6
        words.add("Island"); //6
        words.add("Desert");//6

        arrayAdapter = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_list_item_1, words);
        listView.setAdapter(arrayAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                if (i == 0){
                    Intent intent = new Intent(displayListoWords_1.this, Earthquake.class);
                    startActivity(intent);
                } else if (i == 1){
                    Intent intent = new Intent(displayListoWords_1.this, Continents.class);
                    startActivity(intent);
                } else if (i == 2){
                    Intent intent = new Intent(displayListoWords_1.this, Volcano.class);
                    startActivity(intent);
                } else if (i == 3){
                    Intent intent = new Intent(displayListoWords_1.this, Peninsula.class);
                    startActivity(intent);
                } else if (i == 4){
                    Intent intent = new Intent(displayListoWords_1.this, Glaciers.class);
                    startActivity(intent);
                } else if (i == 5){
                    Intent intent = new Intent(displayListoWords_1.this, Tsunami.class);
                    startActivity(intent);
                } else if (i == 6){
                    Intent intent = new Intent(displayListoWords_1.this, Canyon.class);
                    startActivity(intent);
                } else if (i == 7){
                    Intent intent = new Intent(displayListoWords_1.this, Valley.class);
                    startActivity(intent);
                } else if (i == 8){
                    Intent intent = new Intent(displayListoWords_1.this, Island.class);
                    startActivity(intent);
                } else if (i == 9){
                    Intent intent = new Intent(displayListoWords_1.this, Desert.class);
                    startActivity(intent);
                }
            }
        });

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                displayListoWords_1.this.arrayAdapter.getFilter().filter(query);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                displayListoWords_1.this.arrayAdapter.getFilter().filter(newText);
                return false;
            }
        });
    }


    public void shortest(View view){
        ListView listView = findViewById(R.id.listview);
        SearchView searchView = findViewById(R.id.search_bar);

        List<String> words = new ArrayList<>();

        words.add("Desert");//6
        words.add("Island"); //6
        words.add("Valley"); //6
        words.add("Canyon"); //6
        words.add("Tsunamis"); //7
        words.add("Glaciers"); //8
        words.add("Peninsula"); //9
        words.add("Volcanoes");//10
        words.add("Continents"); //10
        words.add("Earthquakes"); //11


        arrayAdapter = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_list_item_1, words);
        listView.setAdapter(arrayAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                if (i == 0){
                    Intent intent = new Intent(displayListoWords_1.this, Desert.class);
                    startActivity(intent);
                } else if (i == 1){
                    Intent intent = new Intent(displayListoWords_1.this, Island.class);
                    startActivity(intent);
                } else if (i == 2){
                    Intent intent = new Intent(displayListoWords_1.this, Valley.class);
                    startActivity(intent);
                } else if (i == 3){
                    Intent intent = new Intent(displayListoWords_1.this, Canyon.class);
                    startActivity(intent);
                } else if (i == 4){
                    Intent intent = new Intent(displayListoWords_1.this, Tsunami.class);
                    startActivity(intent);
                } else if (i == 5){
                    Intent intent = new Intent(displayListoWords_1.this, Glaciers.class);
                    startActivity(intent);
                } else if (i == 6){
                    Intent intent = new Intent(displayListoWords_1.this, Peninsula.class);
                    startActivity(intent);
                } else if (i == 7){
                    Intent intent = new Intent(displayListoWords_1.this, Volcano.class);
                    startActivity(intent);
                } else if (i == 8){
                    Intent intent = new Intent(displayListoWords_1.this, Continents.class);
                    startActivity(intent);
                } else if (i == 9){
                    Intent intent = new Intent(displayListoWords_1.this, Earthquake.class);
                    startActivity(intent);
                }
            }
        });

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                displayListoWords_1.this.arrayAdapter.getFilter().filter(query);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                displayListoWords_1.this.arrayAdapter.getFilter().filter(newText);
                return false;
            }
        });
    }
}