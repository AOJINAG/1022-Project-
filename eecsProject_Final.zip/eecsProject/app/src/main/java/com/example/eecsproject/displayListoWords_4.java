package com.example.eecsproject;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class displayListoWords_4 extends AppCompatActivity {

    ArrayAdapter<String> arrayAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_listo_words4);


        ListView listView = findViewById(R.id.listview);
        SearchView searchView = findViewById(R.id.search_bar);


        List<String> words = new ArrayList<>();
        words.add("Asteroid");
        words.add("Comet");
        words.add("Galaxy");
        words.add("Milky way");
        words.add("Meteoroid");
        words.add("Universe");
        words.add("Solar System");
        words.add("Artificial Satellites");
        words.add("Gravity");
        words.add("Nebula");
        words.add("Black hole");
        words.add("Orbit");

        arrayAdapter = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_list_item_1, words);
        listView.setAdapter(arrayAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                if (i == 0){
                    Intent intent = new Intent(displayListoWords_4.this, Asteroid.class);
                    startActivity(intent);
                } else if (i == 1){
                    Intent intent = new Intent(displayListoWords_4.this, Comet.class);
                    startActivity(intent);
                } else if (i == 2){
                    Intent intent = new Intent(displayListoWords_4.this, Galaxy.class);
                    startActivity(intent);
                } else if (i == 3){
                    Intent intent = new Intent(displayListoWords_4.this, Milky_way.class);
                    startActivity(intent);
                } else if (i == 4){
                    Intent intent = new Intent(displayListoWords_4.this, Meteoroid.class);
                    startActivity(intent);
                } else if (i == 5){
                    Intent intent = new Intent(displayListoWords_4.this, Universe.class);
                    startActivity(intent);
                } else if (i == 6){
                    Intent intent = new Intent(displayListoWords_4.this, Solar_system.class);
                    startActivity(intent);
                } else if (i == 7){
                    Intent intent = new Intent(displayListoWords_4.this, Artificial_satellites.class);
                    startActivity(intent);
                } else if (i == 8){
                    Intent intent = new Intent(displayListoWords_4.this, Gravity.class);
                    startActivity(intent);
                }else if (i == 9){
                    Intent intent = new Intent(displayListoWords_4.this, Nebula.class);
                    startActivity(intent);
                } else if (i == 10){
                    Intent intent = new Intent(displayListoWords_4.this, black_hole.class);
                    startActivity(intent);
                } else if (i == 9){
                    Intent intent = new Intent(displayListoWords_4.this, Orbit.class);
                    startActivity(intent);
                }
            }
        });

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                displayListoWords_4.this.arrayAdapter.getFilter().filter(query);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                displayListoWords_4.this.arrayAdapter.getFilter().filter(newText);
                return false;
            }
        });
    }

    public void alphabetical(View view){
        ListView listView = findViewById(R.id.listview);
        SearchView searchView = findViewById(R.id.search_bar);

        List<String> words = new ArrayList<>();
        words.add("Artificial Satellites");
        words.add("Asteroid");
        words.add("Black hole");
        words.add("Comet");
        words.add("Galaxy");
        words.add("Gravity");
        words.add("Milky way");
        words.add("Meteoroid");
        words.add("Nebula");
        words.add("Orbit");
        words.add("Solar System");
        words.add("Universe");

        arrayAdapter = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_list_item_1, words);
        listView.setAdapter(arrayAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                if (i == 0){
                    Intent intent = new Intent(displayListoWords_4.this, Artificial_satellites.class);
                    startActivity(intent);
                } else if (i == 1){
                    Intent intent = new Intent(displayListoWords_4.this, Asteroid.class);
                    startActivity(intent);
                } else if (i == 2){
                    Intent intent = new Intent(displayListoWords_4.this, black_hole.class);
                    startActivity(intent);
                } else if (i == 3){
                    Intent intent = new Intent(displayListoWords_4.this, Comet.class);
                    startActivity(intent);
                } else if (i == 4){
                    Intent intent = new Intent(displayListoWords_4.this, Galaxy.class);
                    startActivity(intent);
                } else if (i == 5){
                    Intent intent = new Intent(displayListoWords_4.this, Gravity.class);
                    startActivity(intent);
                } else if (i == 6){
                    Intent intent = new Intent(displayListoWords_4.this, Milky_way.class);
                    startActivity(intent);
                } else if (i == 7){
                    Intent intent = new Intent(displayListoWords_4.this, Meteoroid.class);
                    startActivity(intent);
                } else if (i == 8){
                    Intent intent = new Intent(displayListoWords_4.this, Nebula.class);
                    startActivity(intent);
                } else if (i == 9){
                    Intent intent = new Intent(displayListoWords_4.this, Orbit.class);
                    startActivity(intent);
                } else if (i == 10) {
                    Intent intent = new Intent(displayListoWords_4.this, Solar_system.class);
                    startActivity(intent);
                } else if (i == 11) {
                    Intent intent = new Intent(displayListoWords_4.this, Universe.class);
                    startActivity(intent);
                }
            }
        });

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                displayListoWords_4.this.arrayAdapter.getFilter().filter(query);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                displayListoWords_4.this.arrayAdapter.getFilter().filter(newText);
                return false;
            }
        });
    }


    public void longest(View view){
        ListView listView = findViewById(R.id.listview);
        SearchView searchView = findViewById(R.id.search_bar);

        List<String> words = new ArrayList<>();

        words.add("Artificial Satellites");
        words.add("Solar System");
        words.add("Black hole");
        words.add("Milky way");
        words.add("Meteoroid");
        words.add("Universe");
        words.add("Asteroid");
        words.add("Gravity");
        words.add("Galaxy");
        words.add("Nebula");
        words.add("Orbit");
        words.add("Comet");

        arrayAdapter = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_list_item_1, words);
        listView.setAdapter(arrayAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                if (i == 0){
                    Intent intent = new Intent(displayListoWords_4.this, Artificial_satellites.class);
                    startActivity(intent);
                } else if (i == 1){
                    Intent intent = new Intent(displayListoWords_4.this, Solar_system.class);
                    startActivity(intent);
                } else if (i == 2){
                    Intent intent = new Intent(displayListoWords_4.this, black_hole.class);
                    startActivity(intent);
                } else if (i == 3){
                    Intent intent = new Intent(displayListoWords_4.this, Milky_way.class);
                    startActivity(intent);
                } else if (i == 4){
                    Intent intent = new Intent(displayListoWords_4.this, Meteoroid.class);
                    startActivity(intent);
                } else if (i == 5){
                    Intent intent = new Intent(displayListoWords_4.this, Universe.class);
                    startActivity(intent);
                } else if (i == 6){
                    Intent intent = new Intent(displayListoWords_4.this, Asteroid.class);
                    startActivity(intent);
                } else if (i == 7){
                    Intent intent = new Intent(displayListoWords_4.this, Gravity.class);
                    startActivity(intent);
                } else if (i == 8){
                    Intent intent = new Intent(displayListoWords_4.this, Galaxy.class);
                    startActivity(intent);
                } else if (i == 9){
                    Intent intent = new Intent(displayListoWords_4.this, Nebula.class);
                    startActivity(intent);
                } else if (i == 10) {
                    Intent intent = new Intent(displayListoWords_4.this, Orbit.class);
                    startActivity(intent);
                } else if (i == 11) {
                    Intent intent = new Intent(displayListoWords_4.this, Comet.class);
                    startActivity(intent);
                }
            }
        });

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                displayListoWords_4.this.arrayAdapter.getFilter().filter(query);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                displayListoWords_4.this.arrayAdapter.getFilter().filter(newText);
                return false;
            }
        });
    }


    public void shortest(View view){
        ListView listView = findViewById(R.id.listview);
        SearchView searchView = findViewById(R.id.search_bar);

        List<String> words = new ArrayList<>();
        words.add("Comet");
        words.add("Orbit");
        words.add("Nebula");
        words.add("Galaxy");
        words.add("Gravity");
        words.add("Asteroid");
        words.add("Universe");
        words.add("Meteoroid");
        words.add("Milky way");
        words.add("Black hole");
        words.add("Solar System");
        words.add("Artificial Satellites");


        arrayAdapter = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_list_item_1, words);
        listView.setAdapter(arrayAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                if (i == 0){
                    Intent intent = new Intent(displayListoWords_4.this, Comet.class);
                    startActivity(intent);
                } else if (i == 1){
                    Intent intent = new Intent(displayListoWords_4.this, Orbit.class);
                    startActivity(intent);
                } else if (i == 2){
                    Intent intent = new Intent(displayListoWords_4.this, Nebula.class);
                    startActivity(intent);
                } else if (i == 3){
                    Intent intent = new Intent(displayListoWords_4.this, Galaxy.class);
                    startActivity(intent);
                } else if (i == 4){
                    Intent intent = new Intent(displayListoWords_4.this, Gravity.class);
                    startActivity(intent);
                } else if (i == 5){
                    Intent intent = new Intent(displayListoWords_4.this, Asteroid.class);
                    startActivity(intent);
                } else if (i == 6){
                    Intent intent = new Intent(displayListoWords_4.this, Universe.class);
                    startActivity(intent);
                } else if (i == 7){
                    Intent intent = new Intent(displayListoWords_4.this, Meteoroid.class);
                    startActivity(intent);
                } else if (i == 8){
                    Intent intent = new Intent(displayListoWords_4.this, Milky_way.class);
                    startActivity(intent);
                } else if (i == 9){
                    Intent intent = new Intent(displayListoWords_4.this, black_hole.class);
                    startActivity(intent);
                } else if (i == 10) {
                    Intent intent = new Intent(displayListoWords_4.this, Solar_system.class);
                    startActivity(intent);
                } else if (i == 11) {
                    Intent intent = new Intent(displayListoWords_4.this, Artificial_satellites.class);
                    startActivity(intent);
                }
            }
        });

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                displayListoWords_4.this.arrayAdapter.getFilter().filter(query);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                displayListoWords_4.this.arrayAdapter.getFilter().filter(newText);
                return false;
            }
        });
    }
}